User

const webpack = require('webpack'),
 path = require('path'),
 { merge } = require("webpack-merge"),
 common = require("./webpack.common");


module.exports = merge(common, {
 
    mode: 'development',
    devtool: 'source-map',
    module: {
      rules: [
      
        {
          test: /\.s[ac]ss$/i,
          use: ["style-loader", "css-loader", "sass-loader"]
        }
      ],
    },
   
    plugins: [
     
     
      ],
      optimization: {
        minimizer: [
          new CssMinimizerPlugin(),
          // Other minimizers if needed
        ],
      },
      minimize: true,
  });