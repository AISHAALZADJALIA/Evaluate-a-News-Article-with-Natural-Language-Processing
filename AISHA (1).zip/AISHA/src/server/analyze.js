const axios = require("axios");
const { response } = require("express");
const { CleanPlugin } = require("webpack");
const meaningCloud = "https://api.meaningcloud.com/sentiment-2.1"


const analyze = async (url, key) => {
    // the URL=`${BASE_API_URL}?key=${MEAN_CLOUD_API_KEY}&url=${req.body.url}&lang=en`

  const analysis = await axios.get('${meaningCloud}?key=${key}&url=${url}&lang=en')
  .then(response => {
   const {code} = response.data.status
   const {msg} = response.data.status
   if (code == 100){
 return handleErrors(code, "please enter correct url")
 
}
else if (code == 212){
  return handleErrors(code, msg)
} 
return handleSuccess(response.data, code)
   }
   );
return analysis
};
const handleErrors = (code, msg) =>{
  const error = {
    code,
    msg
  }
  return error
}

//cure the data and send to client
const handleSuccess = (data, code) =>{
  const {text, polarity, agreement, subjectivity, confidence, irony, score_tag} = data
  const sample = {
    text: text,
    polarity: polarity,
    agreement: agreement,
    subjectivity: subjectivity, 
    confidence: confidence,
    irony: irony, 
    score_tag: score_tag
    } 
   const result = { sample, code }
   return result
}
module.exports = { analyze };