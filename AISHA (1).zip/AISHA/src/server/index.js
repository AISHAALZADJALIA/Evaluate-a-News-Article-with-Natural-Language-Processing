const express = require("express")
const app = express();
const cors = require("cors");
const {analyze} = require("./analyze.js")
const dotenv = require("dotenv")
//use cors


app.use(cors()) 
dotenv.config()
port = 8000
const key = process.env.API_KEY
// read the json files
app.use(express.json())
app.use(express.static('dist'))
//configure my env files


app.get("/", (req, res) => {
    res.git("dist/index.html")
})

app.post("/", async (req, res) => {
 const url =  req.body.input;
 const Analyze = await analyze(url, key) 
 const {code, msg, sample} = Analyze
  if(code == 100 || code == 212){  return res.send({msg: msg, code :code})

}
return res.send({sample: sample, code: code})
})

app.listen(8000, () => console.log('server is listening on port ${port}'))