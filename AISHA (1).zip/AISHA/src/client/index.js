/*alert("hello client");*/
import "./style/base.scss"
import "./style/footer.scss"
import "./style/form.scss"
import "./style/header.scss"
import "./style/resets.scss"
import "./style/style.scss"


import {handleSubmit} from "./js/handleSubmit"

export {handleSubmit}

