const webpack = require('webpack'),
  path = require('path'),
  TerserPlugin = require("terser-webpack-plugin"),
  CssMinimizerPlugin = require("css-minimizer-webpack-plugin"),
  MiniCssExtractPlugin = require("mini-css-extract-plugin"),
  { merge } = require("webpack-merge"),
  common = require("./webpack.common");

module.exports = merge(common, {

  mode: 'development',
  devtool: 'hidden-source-map',
  module: {
    rules: [
      {
        test: /\.s[ac]ss$/i,
        use: [MiniCssExtractPlugin.loader, "css-loader", "sass-loader"]
      }
    ],
  },
  optimization: {
    minimizer: [
      new CssMinimizerPlugin(),
      new TerserPlugin()
    ],
    minimize: true,
  },
});
